#include<iostream>

//Typing Code For My Calculator
// Defining all the variables
using namespace std;


System::Int32 num1;
System::Int32 num2;

char opp;
int textBoxNumber = 1;
// Defining all the Functions


void changeTextBoxNumber(int *tbn) {
	if (*tbn == 1) {
		*tbn = 2;
	}
	else if (*tbn == 2) {
		*tbn = 1;
	}
}


void updateTEXTBOX(System::Windows::Forms::TextBox^ tBox1, System::Windows::Forms::TextBox^ tBox2, int n ,int tbn) {


	if(tbn == 1) {
		//code
		if (tBox1->Text == "0" && tBox1->Text->Length == 1) {
			tBox1->Text = "";
		}
		tBox1->Text = tBox1->Text + n;
	}
	else if (tbn == 2) {
		//code
		if (tBox2->Text == "0" && tBox2->Text->Length == 1) {
			tBox2->Text = "";
		}
		tBox2->Text = tBox2->Text + n;
	}
}






#pragma once
namespace CppCLRWinFormsProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;



	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Panel^ panel1;



















	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ button16;
	private: System::Windows::Forms::Button^ button18;
	private: System::Windows::Forms::Button^ button12;
	private: System::Windows::Forms::Button^ button13;
	private: System::Windows::Forms::Button^ button14;
	private: System::Windows::Forms::Button^ button15;
	private: System::Windows::Forms::Button^ button7;
	private: System::Windows::Forms::Button^ button8;
	private: System::Windows::Forms::Button^ button9;
	private: System::Windows::Forms::Button^ button10;
	private: System::Windows::Forms::Button^ button5;
	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::TextBox^ textBox2;
	private: System::Windows::Forms::Button^ button6;
	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->button16 = (gcnew System::Windows::Forms::Button());
			this->button18 = (gcnew System::Windows::Forms::Button());
			this->button12 = (gcnew System::Windows::Forms::Button());
			this->button13 = (gcnew System::Windows::Forms::Button());
			this->button14 = (gcnew System::Windows::Forms::Button());
			this->button15 = (gcnew System::Windows::Forms::Button());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->button10 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->panel1->SuspendLayout();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->BackColor = System::Drawing::SystemColors::InactiveCaption;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei", 27.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(45, 132);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(338, 50);
			this->label1->TabIndex = 0;
			this->label1->Text = L"0";
			this->label1->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->label1->Click += gcnew System::EventHandler(this, &Form1::label1_Click);
			// 
			// textBox1
			// 
			this->textBox1->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox1->Location = System::Drawing::Point(45, 57);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(147, 43);
			this->textBox1->TabIndex = 1;
			this->textBox1->Text = L"0";
			this->textBox1->TextChanged += gcnew System::EventHandler(this, &Form1::textBox1_TextChanged);
			// 
			// label2
			// 
			this->label2->BackColor = System::Drawing::Color::Transparent;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(179, 57);
			this->label2->Name = L"label2";
			this->label2->Padding = System::Windows::Forms::Padding(10, 0, 10, 0);
			this->label2->Size = System::Drawing::Size(63, 43);
			this->label2->TabIndex = 2;
			this->label2->TextAlign = System::Drawing::ContentAlignment::TopRight;
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::Color::Transparent;
			this->panel1->Controls->Add(this->button6);
			this->panel1->Controls->Add(this->button16);
			this->panel1->Controls->Add(this->button18);
			this->panel1->Controls->Add(this->button12);
			this->panel1->Controls->Add(this->button13);
			this->panel1->Controls->Add(this->button14);
			this->panel1->Controls->Add(this->button15);
			this->panel1->Controls->Add(this->button7);
			this->panel1->Controls->Add(this->button8);
			this->panel1->Controls->Add(this->button9);
			this->panel1->Controls->Add(this->button10);
			this->panel1->Controls->Add(this->button5);
			this->panel1->Controls->Add(this->button4);
			this->panel1->Controls->Add(this->button3);
			this->panel1->Controls->Add(this->button2);
			this->panel1->Controls->Add(this->button1);
			this->panel1->Location = System::Drawing::Point(37, 205);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(357, 369);
			this->panel1->TabIndex = 3;
			this->panel1->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &Form1::panel1_Paint);
			// 
			// button6
			// 
			this->button6->Font = (gcnew System::Drawing::Font(L"Segoe UI", 27.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button6->Location = System::Drawing::Point(266, 16);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(80, 64);
			this->button6->TabIndex = 20;
			this->button6->Text = L"C";
			this->button6->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Click += gcnew System::EventHandler(this, &Form1::button6_Click);
			// 
			// button16
			// 
			this->button16->BackColor = System::Drawing::Color::CornflowerBlue;
			this->button16->Font = (gcnew System::Drawing::Font(L"Segoe UI", 27.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button16->ImageAlign = System::Drawing::ContentAlignment::BottomCenter;
			this->button16->Location = System::Drawing::Point(266, 226);
			this->button16->Name = L"button16";
			this->button16->Padding = System::Windows::Forms::Padding(0, 30, 0, 0);
			this->button16->Size = System::Drawing::Size(80, 134);
			this->button16->TabIndex = 19;
			this->button16->Text = L"=";
			this->button16->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			this->button16->UseVisualStyleBackColor = false;
			this->button16->Click += gcnew System::EventHandler(this, &Form1::button16_Click);
			// 
			// button18
			// 
			this->button18->Font = (gcnew System::Drawing::Font(L"Segoe UI", 27.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button18->Location = System::Drawing::Point(266, 86);
			this->button18->Name = L"button18";
			this->button18->Size = System::Drawing::Size(80, 134);
			this->button18->TabIndex = 17;
			this->button18->Text = L"+";
			this->button18->UseVisualStyleBackColor = true;
			this->button18->Click += gcnew System::EventHandler(this, &Form1::button18_Click);
			// 
			// button12
			// 
			this->button12->Font = (gcnew System::Drawing::Font(L"Segoe UI", 27.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button12->Location = System::Drawing::Point(180, 226);
			this->button12->Name = L"button12";
			this->button12->Size = System::Drawing::Size(80, 64);
			this->button12->TabIndex = 13;
			this->button12->Text = L"3";
			this->button12->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			this->button12->UseVisualStyleBackColor = true;
			this->button12->Click += gcnew System::EventHandler(this, &Form1::button12_Click);
			// 
			// button13
			// 
			this->button13->Font = (gcnew System::Drawing::Font(L"Segoe UI", 27.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button13->Location = System::Drawing::Point(180, 156);
			this->button13->Name = L"button13";
			this->button13->Size = System::Drawing::Size(80, 64);
			this->button13->TabIndex = 12;
			this->button13->Text = L"6";
			this->button13->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			this->button13->UseVisualStyleBackColor = true;
			this->button13->Click += gcnew System::EventHandler(this, &Form1::button13_Click);
			// 
			// button14
			// 
			this->button14->Font = (gcnew System::Drawing::Font(L"Segoe UI", 27.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button14->Location = System::Drawing::Point(180, 86);
			this->button14->Name = L"button14";
			this->button14->Size = System::Drawing::Size(80, 64);
			this->button14->TabIndex = 11;
			this->button14->Text = L"9";
			this->button14->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			this->button14->UseVisualStyleBackColor = true;
			this->button14->Click += gcnew System::EventHandler(this, &Form1::button14_Click);
			// 
			// button15
			// 
			this->button15->BackColor = System::Drawing::Color::Transparent;
			this->button15->FlatAppearance->BorderSize = 0;
			this->button15->Font = (gcnew System::Drawing::Font(L"Segoe UI", 27.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button15->Location = System::Drawing::Point(180, 16);
			this->button15->Name = L"button15";
			this->button15->Size = System::Drawing::Size(80, 64);
			this->button15->TabIndex = 10;
			this->button15->Text = L"-";
			this->button15->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			this->button15->UseVisualStyleBackColor = false;
			this->button15->Click += gcnew System::EventHandler(this, &Form1::button15_Click);
			// 
			// button7
			// 
			this->button7->Font = (gcnew System::Drawing::Font(L"Segoe UI", 27.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button7->Location = System::Drawing::Point(94, 226);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(80, 64);
			this->button7->TabIndex = 8;
			this->button7->Text = L"2";
			this->button7->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			this->button7->UseVisualStyleBackColor = true;
			this->button7->Click += gcnew System::EventHandler(this, &Form1::button7_Click);
			// 
			// button8
			// 
			this->button8->Font = (gcnew System::Drawing::Font(L"Segoe UI", 27.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button8->Location = System::Drawing::Point(94, 156);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(80, 64);
			this->button8->TabIndex = 7;
			this->button8->Text = L"5";
			this->button8->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			this->button8->UseVisualStyleBackColor = true;
			this->button8->Click += gcnew System::EventHandler(this, &Form1::button8_Click);
			// 
			// button9
			// 
			this->button9->Font = (gcnew System::Drawing::Font(L"Segoe UI", 27.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button9->Location = System::Drawing::Point(94, 86);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(80, 64);
			this->button9->TabIndex = 6;
			this->button9->Text = L"8";
			this->button9->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			this->button9->UseVisualStyleBackColor = true;
			this->button9->Click += gcnew System::EventHandler(this, &Form1::button9_Click);
			// 
			// button10
			// 
			this->button10->Font = (gcnew System::Drawing::Font(L"Segoe UI", 27.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button10->Location = System::Drawing::Point(94, 16);
			this->button10->Name = L"button10";
			this->button10->Size = System::Drawing::Size(80, 64);
			this->button10->TabIndex = 5;
			this->button10->Text = L"*";
			this->button10->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			this->button10->UseVisualStyleBackColor = true;
			this->button10->Click += gcnew System::EventHandler(this, &Form1::button10_Click);
			// 
			// button5
			// 
			this->button5->Font = (gcnew System::Drawing::Font(L"Segoe UI", 27.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button5->Location = System::Drawing::Point(8, 296);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(252, 64);
			this->button5->TabIndex = 4;
			this->button5->Text = L"0";
			this->button5->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &Form1::button5_Click);
			// 
			// button4
			// 
			this->button4->Font = (gcnew System::Drawing::Font(L"Segoe UI", 27.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button4->Location = System::Drawing::Point(8, 226);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(80, 64);
			this->button4->TabIndex = 3;
			this->button4->Text = L"1";
			this->button4->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Form1::button4_Click);
			// 
			// button3
			// 
			this->button3->Font = (gcnew System::Drawing::Font(L"Segoe UI", 27.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button3->Location = System::Drawing::Point(8, 156);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(80, 64);
			this->button3->TabIndex = 2;
			this->button3->Text = L"4";
			this->button3->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// button2
			// 
			this->button2->Font = (gcnew System::Drawing::Font(L"Segoe UI", 27.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button2->Location = System::Drawing::Point(8, 86);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(80, 64);
			this->button2->TabIndex = 1;
			this->button2->Text = L"7";
			this->button2->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// button1
			// 
			this->button1->Font = (gcnew System::Drawing::Font(L"Segoe UI", 27.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button1->Location = System::Drawing::Point(8, 16);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(80, 64);
			this->button1->TabIndex = 0;
			this->button1->Text = L"/";
			this->button1->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// textBox2
			// 
			this->textBox2->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox2->Location = System::Drawing::Point(236, 57);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(147, 43);
			this->textBox2->TabIndex = 4;
			this->textBox2->Text = L"0";
			this->textBox2->TextChanged += gcnew System::EventHandler(this, &Form1::textBox2_TextChanged);
			// 
			// Form1
			// 
			this->AccessibleName = L"Calculator";
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(434, 601);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->label2);
			this->Cursor = System::Windows::Forms::Cursors::Hand;
			this->Name = L"Form1";
			this->Text = L"Calculator";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->panel1->ResumeLayout(false);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label1_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void panel1_Paint(System::Object^ sender, System::Windows::Forms::PaintEventArgs^ e) {
	}

	private: System::Void button16_Click(System::Object^ sender, System::EventArgs^ e) {
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
		//Convert::ToDouble
		if (opp == '+') {
			label1->Text = Convert::ToString(Convert::ToInt32(textBox2->Text) + Convert::ToInt32(textBox1->Text));
		}
		else if (opp == '-'){
			label1->Text = Convert::ToString(Convert::ToInt32(textBox1->Text) - Convert::ToInt32(textBox2->Text));
		}
		else if (opp == '*') {
			label1->Text = Convert::ToString(Convert::ToInt32(textBox2->Text) * Convert::ToInt32(textBox1->Text));
		}
		else if (opp == '/') {
			label1->Text = Convert::ToString(Convert::ToDouble(textBox1->Text) / Convert::ToDouble(textBox2->Text));
		}

		
	}
	
private: System::Void button18_Click(System::Object^ sender, System::EventArgs^ e) {
	changeTextBoxNumber(&textBoxNumber);
	opp = '+';
	label2->Text = "+";
}
private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {

	updateTEXTBOX(textBox1, textBox2, 1, textBoxNumber);

}
private: System::Void button15_Click(System::Object^ sender, System::EventArgs^ e) {
	changeTextBoxNumber(&textBoxNumber);
	opp = '-';
	label2->Text = "-";
}
private: System::Void button10_Click(System::Object^ sender, System::EventArgs^ e) {
	changeTextBoxNumber(&textBoxNumber);
	opp = '*';
	label2->Text = "*";
}
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	changeTextBoxNumber(&textBoxNumber);
	opp = '/';
	label2->Text = "/";
}
private: System::Void textBox2_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void button5_Click(System::Object^ sender, System::EventArgs^ e) {
	updateTEXTBOX(textBox1, textBox2, 0, textBoxNumber);
}
private: System::Void button7_Click(System::Object^ sender, System::EventArgs^ e) {
	updateTEXTBOX(textBox1, textBox2, 2, textBoxNumber);
}
private: System::Void button12_Click(System::Object^ sender, System::EventArgs^ e) {
	updateTEXTBOX(textBox1, textBox2, 3, textBoxNumber);
}
private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {
	updateTEXTBOX(textBox1, textBox2, 4, textBoxNumber);
}
private: System::Void button8_Click(System::Object^ sender, System::EventArgs^ e) {
	updateTEXTBOX(textBox1, textBox2, 5, textBoxNumber);
}
private: System::Void button13_Click(System::Object^ sender, System::EventArgs^ e) {
	updateTEXTBOX(textBox1, textBox2, 6, textBoxNumber);
}
private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
	updateTEXTBOX(textBox1, textBox2, 7, textBoxNumber);
}
private: System::Void button9_Click(System::Object^ sender, System::EventArgs^ e) {
	updateTEXTBOX(textBox1, textBox2, 8, textBoxNumber);
}
private: System::Void button14_Click(System::Object^ sender, System::EventArgs^ e) {
	updateTEXTBOX(textBox1, textBox2, 9, textBoxNumber);
}
private: System::Void Form1_Load(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void button6_Click(System::Object^ sender, System::EventArgs^ e) {
	textBox1->Text = "0";
	textBox2->Text = "0";
	label1->Text = "0";
	textBoxNumber = 1;
}
private: System::Void textBox1_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}
};
}
